<?php
define('DB_HOST','localhost');
define('DB_USERNAME','mydmc001_dealer');
define('DB_PASSWORD','Khanyisa18');
define('DB_NAME','mydmc001_dealership');
?>